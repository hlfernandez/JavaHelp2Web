function initManual() {
	$('#tabs').tabs();
	
	$('a').each(function() {
		var href = $(this).attr("href");

		if (linkToAnchor[href] !== undefined) {
			var tabAndAnchor = linkToAnchor[href].split("#");
			$(this).attr("data-tabindex", tabAndAnchor[0]);
			$(this).attr("href", "#" + tabAndAnchor[1]);
		}
	});

	$('a[data-tabindex]').click(function() {
		var index = $(this).data("tabindex");
		if (index !== undefined) 
			$('#tabs').tabs({ active: index });
	});

	$('img').each(function() {
		var src = $(this).attr('src');
		$(this).attr('src', src.replace(/[../]*Images/, "HTML/Images"));
		$(this).css("max-width", "700px");				
	});
	
	$('a').each(function() {
		var href = $(this).attr('href');
		$(this).attr('href', href.replace(/[../]*Images/, "./HTML/Images"));
	});

	$('#clientVersionHistoryHeader').click(function() {
		$('#clientVersionHistory').slideToggle("slow");
	});

	$('#serverVersionHistoryHeader').click(function() {
		$('#serverVersionHistory').slideToggle("slow");
	});
		
	 if(window.location.hash) {
		var hash = window.location.hash;
		$('#indexTab a').each(function() {
			var href = $(this).attr('href');
			var index = $(this).data("tabindex");
			if (hash === href) {
				if (index !== undefined) 
					$('#tabs').tabs({ active: index });
				$(this).click();
			}
		});
	 }
}